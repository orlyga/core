<?php
App::uses('AppModel', 'Model');
class PhotonAppModel extends AppModel {

}
?>