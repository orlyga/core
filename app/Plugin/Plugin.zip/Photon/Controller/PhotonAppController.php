<?php
class PhotonAppController extends AppController {

}
?>